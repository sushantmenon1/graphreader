import nltk


nltk.download("wordnet")